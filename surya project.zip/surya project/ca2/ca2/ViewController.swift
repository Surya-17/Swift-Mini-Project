//
//  ViewController.swift
//  ca2
//
//  Created by Student on 21/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    @IBOutlet weak var ageslider: UISlider!
    
    @IBOutlet weak var agepricelabel: UITextField!
    
    
    
    @IBOutlet weak var cybersecurity: UISwitch!
    
    @IBOutlet weak var price1: UILabel!
    
    @IBOutlet weak var Quantitylb1: UITextField!
    
}

