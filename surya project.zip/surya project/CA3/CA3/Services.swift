//
//  Services.swift
//  CA3
//
//  Created by Student on 04/11/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class Services: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func xray(_ sender: UIButton) {
        performSegue(withIdentifier: "booking", sender: self)
    }
    
    
    @IBAction func btest(_ sender: UIButton) {
        performSegue(withIdentifier: "booking", sender: self)
    }
    
    @IBAction func ctscan(_ sender: UIButton) {
        performSegue(withIdentifier: "booking", sender: self)
    }
    
    
    /*
          // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
