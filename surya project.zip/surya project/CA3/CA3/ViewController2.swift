//
//  ViewController2.swift
//  CA3
//
//  Created by Student on 21/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController2: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var hosp: [String] = ["Doctors","Services","Patient"]
    var Doctors: [String] = ["Dr John","Dr Steve","Dr Mark"]
    var Services: [String] = ["Lab"]
    var Patient: [String] = ["Reports","Symptoms"]
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return hosp.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section==0){
            return Doctors.count
        }
        else if(section==1){
            return Services.count
        }
        else{
            return Patient.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseCell", for: indexPath)
        if(indexPath.section == 0){
            cell.textLabel?.text = Doctors[indexPath.row]
        }
        else if(indexPath.section==1){
            cell.textLabel?.text = Services[indexPath.row]
        }
        else{
            cell.textLabel?.text = Patient[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return hosp[section]
    }
   // var value:String!
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(indexPath.section==0){
            //value=Doctors[indexPath.row]
            performSegue(withIdentifier: "info", sender: self)
        }
        else if(indexPath.section==1){
           // value=Lab[indexPath.row]
            performSegue(withIdentifier: "services", sender: self)
        }
        else{
           performSegue(withIdentifier: "reports", sender: self)
            // value=Patient[indexPath.row]
        }
        //let alert = UIAlertController(title: "Welcome", message: value, preferredStyle: .alert)
       // alert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
        //self.present(alert, animated: true, completion: nil)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
}
