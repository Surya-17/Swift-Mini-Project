//
//  booking.swift
//  CA3
//
//  Created by Student on 04/11/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class booking: UIViewController {
    var data: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bookingconfirm.text = "Thank for choosing our MedCare Health Services, Your \(data) service has been booked"
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var bookingconfirm: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
