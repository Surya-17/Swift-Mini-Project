//
//  ViewController.swift
//  CA3
//
//  Created by Student on 21/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var pwd: UITextField!
    
    
    @IBAction func login(_ sender: UIButton) {
        if(username.text == "Surya" && pwd.text == "admin"){
            performSegue(withIdentifier: "appointment", sender: self)
        }
        else{
            let alert=UIAlertController(title: "ERROR", message: "Wrong Username or Password", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Retry", style: .cancel, handler: nil))
            self.present(alert,animated: true, completion: nil)
        }
    }
    
    
}

