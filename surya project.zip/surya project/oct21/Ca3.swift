//
//  ViewController2.swift
//  oct21
//
//  Created by Student on 21/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func segment1(_ sender: UISegmentedControl) {
        if(sender.selectedSegmentIndex==0)
        {
            self.view.backgroundColor=UIColor.black
        }
        
         if(sender.selectedSegmentIndex==1)
         {
             self.view.backgroundColor=UIColor.green
        }
        
        
    }
    
    @IBOutlet weak var text5: UITextField!
    @IBAction func segment2(_ sender: UISegmentedControl) {
        if(sender.selectedSegmentIndex==0)
        {
            text5.text="Male"
        }
        if(sender.selectedSegmentIndex==1)
        {
            text5.text="Female"
        }
    }
  
    var mo:Int=0
    @IBOutlet weak var text7: UITextField!
    @IBOutlet weak var text8: UITextField!
    @IBAction func tax(_ sender: UIButton) {
        
        
        if Int(text7.text!)! <= 150000
        {
            mo = Int(text7.text!)!
            mo = (mo*5)/100
            text8.text = String(mo)
            
        }
        else if Int(text7.text!)! >= 150000 && Int(text7.text!)! <= 200000
        {
 
            mo = Int(text7.text!)!
            mo = (mo*10)/100
            text8.text = String(mo)        }
        else if Int(text7.text!)! >= 200000 && Int(text7.text!)! <= 250000
        {
 
            mo = Int(text7.text!)!
            mo = (mo*15)/100
            text8.text = String(mo)
        }
        
    }
    
}

