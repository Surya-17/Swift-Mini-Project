//
//  ViewController.swift
//  oct21
//
//  Created by Student on 21/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var text1: UITextField!
    @IBOutlet weak var text2: UITextField!
    
    @IBAction func next(_ sender: UIButton) {
     
        if text1.text=="login"  && text2.text=="1234"
        {
          performSegue(withIdentifier: "main", sender: nil)
        }
        
        else
        {
            text1.text=""
            text2.text=""
            let alert=UIAlertController(title:"login", message:"invalid", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
}
