//
//  ViewController.swift
//  testt
//
//  Created by Student on 27/10/22.
//  Copyright © 2022 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    
    
    
    
    @IBAction func stud(_ sender: UIButton) {
        performSegue(withIdentifier: "stud", sender: self)
        sdata = t1.text!
    }
    
    
    @IBAction func teach(_ sender: UIButton) {
    
        performSegue(withIdentifier: "teach", sender: self)
        tdata = t1.text!
    }
    
    
    @IBOutlet weak var t1: UITextField!
    

}

